//
//  Benji.h
//  Benji
//
//  Created by Aaron Wong on 2019-11-21.
//  Copyright © 2019 Aaron Wong. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Benji.
FOUNDATION_EXPORT double BenjiVersionNumber;

//! Project version string for Benji.
FOUNDATION_EXPORT const unsigned char BenjiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Benji/PublicHeader.h>


